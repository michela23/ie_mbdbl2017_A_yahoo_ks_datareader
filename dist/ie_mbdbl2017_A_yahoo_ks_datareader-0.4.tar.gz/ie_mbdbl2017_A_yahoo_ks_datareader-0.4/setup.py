from setuptools import setup

setup(name='ie_mbdbl2017_A_yahoo_ks_datareader',
      version='0.4',  # Development release
      description='Python Packaging Starting Kit - Simple Structure to create your own package - for training purposes!',
	  long_description='Python Packaging Starting Kit - Simple Structure to create your own package - for training purposes!',
      url='https://github.com/michela23/ie_mbdbl2017_A_yahoo_ks_datareader',
      author='IE GMBD 2017 Group A',
      author_email='michel.aa@student.ie.edu',
      license='MIT',
          packages=['ie_mbdbl2017_A_yahoo_ks_datareader'],
      zip_safe=False)