def  datareader_doc():
    """ function to return the string 'My first Python package that anyone call install it! How cool!!!' """
    return("IE GMBD 2017 Group A first package that anyone can install it! The purpose of the package is to read the technology stock prices between 2 dates")
